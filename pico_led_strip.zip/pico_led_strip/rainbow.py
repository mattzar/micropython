import time
from neopixel import Neopixel

numpixels = 100  # Number of NeoPixels
port = 28
state_machine = 0
mode = "GRB"
delay = 0.03
# Pin where NeoPixels are connected
pixels = Neopixel(numpixels, state_machine, port, mode, delay)
pixels.brightness(20)

red = (255, 0, 0)
orange = (255, 165, 0)
yellow = (255, 150, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
indigo = (75, 0, 130)
violet = (138, 43, 226)
colors_rgb = (red, orange, yellow, green, blue, indigo, violet)

# same colors as normaln rgb, just 0 added at the end
colors_rgbw = [color + (0, ) for color in colors_rgb]
colors_rgbw.append((0, 0, 0, 255))

# uncomment colors_rgb if you have RGB strip
# colors = colors_rgb
colors = colors_rgbw

pixels.brightness(100)

while True:
    for color in colors:
        for i in range(numpixels):
            pixels.set_pixel(i, color)
            time.sleep(delay)
            pixels.show()
