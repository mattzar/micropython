# Example showing use of HSV colors
import time
from neopixel import Neopixel

numpixels = 100  # Number of NeoPixels
port = 28
state_machine = 0
mode = "RGB"
delay = 0.08
# Pin where NeoPixels are connected
strip = Neopixel(numpixels, state_machine, port, mode, delay)
strip.brightness(150)
hue = 0

while(True):
    color = strip.colorHSV(hue, 255, 150)
    strip.fill(color)
    strip.show()
    
    hue += 150