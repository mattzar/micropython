from neopixel import Neopixel

numpixels = 100  # Number of NeoPixels
port = 28
state_machine = 0
mode = "GRB"
delay = 0.001
# Pin where NeoPixels are connected
pixels = Neopixel(numpixels, state_machine, port, mode, delay)
pixels.brightness(20)

pixels.fill((255, 200, 50))
pixels.show()