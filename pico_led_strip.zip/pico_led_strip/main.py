import time
from neopixel import Neopixel

NUM_PIXELS = 100  # Number of NeoPixels
PORT = 28
STATE_MACHINE = 0
DELAY = 0.01
MODE = "GRB"

PROGRAM = 'program.csv'

strip = Neopixel(NUM_PIXELS, STATE_MACHINE, PORT, MODE, DELAY)

def read_csv(filename):
    with open(filename,'r') as file:
        return tuple(line.rstrip('\n\r').split(',') for line in file)


program = read_csv(PROGRAM)
print(program)



